create schema toysgroup;

use toysgroup;

CREATE TABLE `toysgroup`.`product` (
  `idprodotto` INT NOT NULL AUTO_INCREMENT,
  `nome_prodotto` VARCHAR(45) NOT NULL,
  `categoria` VARCHAR(45) NOT NULL,
  `prezzo` DECIMAL(10,2) NOT NULL,
  `descrizione` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idprodotto`));
  
  CREATE TABLE `toysgroup`.`region` (
  `idregione` INT NOT NULL AUTO_INCREMENT,
  `nome_regione` VARCHAR(45) NOT NULL,
  `paese` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idregione`));
  
  CREATE TABLE `toysgroup`.`sales` (
  `idvendita` INT NOT NULL AUTO_INCREMENT,
  `idprodotto` INT NOT NULL,
  `idregione` INT NOT NULL,
  `data_vendita` DATE NOT NULL,
  `quantita` INT NOT NULL,
  `prezzo_unitario` DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (`idvendita`),
  INDEX `sales_product_idx` (`idprodotto` ASC) ,
  INDEX `sales_region_idx` (`idregione` ASC) ,
  CONSTRAINT `sales_product`
    FOREIGN KEY (`idprodotto`)
    REFERENCES `toysgroup`.`product` (`idprodotto`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `sales_region`
    FOREIGN KEY (`idregione`)
    REFERENCES `toysgroup`.`region` (`idregione`)
    ON DELETE CASCADE
    ON UPDATE CASCADE);
    
    INSERT INTO product (idprodotto, nome_prodotto, categoria, prezzo, descrizione) VALUES
(1, 'Bambola Barbie', 'Bambole', 29.99, 'Bambola classica con accessori'),
(2, 'Macchinina Hot Wheels', 'Automobili', 3.99, 'Macchinina giocattolo assortita'),
(3, 'Set di costruzioni LEGO', 'Giochi da costruzione', 19.99, 'Set di mattoncini '),
(4, 'Peluche Orsetto', 'Animali di peluche', 14.99, 'Morbido orsetto '),
(5, 'Monopoly', 'Giochi da tavolo', 24.99, 'Gioco di società '),
(6, 'Puzzle da 100 pezzi', 'Puzzle', 7.99, 'Puzzle con immagini '),
(7, 'Palline colorate', 'Giochi per bambini', 5.99, 'Set di palline in plastica'),
(8, 'Gioco di carte Uno', 'Giochi di carte', 2.99, 'Gioco di carte '),
(9, 'Libro di fiabe', 'Libri per bambini', 9.99, 'Raccolta di fiabe classiche illustrate'),
(10, 'Tavolo da disegno', 'Giochi creativi', 39.99, 'Tavolo con lavagna bianca');

INSERT INTO region (idregione, nome_regione, paese) VALUES
(1, 'Sicilia', 'Italia'),
(2, 'Lombardia', 'Italia'),
(3, 'Emilia-Romagna', 'Italia'),
(4, 'Ile-de-France', 'Francia'),
(5, 'Catalunya', 'Spagna');

INSERT INTO `toysgroup`.`sales` (`idvendita`, `idprodotto`, `idregione`, `data_vendita`, `quantita`, `prezzo_unitario`) VALUES ('1', '1', '3', '2024-01-01', '2', '29.99');
INSERT INTO `toysgroup`.`sales` (`idvendita`, `idprodotto`, `idregione`, `data_vendita`, `quantita`, `prezzo_unitario`) VALUES ('2', '3', '1', '2024-03-02', '1', '19.99');
INSERT INTO `toysgroup`.`sales` (`idvendita`, `idprodotto`, `idregione`, `data_vendita`, `quantita`, `prezzo_unitario`) VALUES ('3', '5', '2', '2024-02-27', '3', '24.99');
INSERT INTO `toysgroup`.`sales` (`idvendita`, `idprodotto`, `idregione`, `data_vendita`, `quantita`, `prezzo_unitario`) VALUES ('4', '4', '4', '2024-03-05', '2', '14.99');
INSERT INTO `toysgroup`.`sales` (`idvendita`, `idprodotto`, `idregione`, `data_vendita`, `quantita`, `prezzo_unitario`) VALUES ('5', '3', '5', '2024-01-25', '1', '29.99');
INSERT INTO `toysgroup`.`sales` (`idvendita`, `idprodotto`, `idregione`, `data_vendita`, `quantita`, `prezzo_unitario`) VALUES ('6', '2', '5', '2024-04-19', '3', '19.99');

/*Verificare che i campi definiti come PK siano univoci*/  

SELECT (product.idprodotto) as codice_prodotto , COUNT(*) AS conteggio
FROM product
GROUP BY codice_prodotto;

SELECT (region.idregione) as codice_regione , COUNT(*) AS conteggio
FROM region
GROUP BY codice_regione;
  
SELECT (sales.idvendita) as codice_vendita , COUNT(*) AS conteggio
FROM sales
GROUP BY codice_vendita;  

/*Esporre l’elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno*/

 SELECT 
    nome_prodotto,
    SUM(quantita * prezzo_unitario) AS totale,
    YEAR(data_vendita) AS anno
FROM
    sales
        JOIN
    product ON sales.idprodotto = product.idprodotto
GROUP BY nome_prodotto , anno;

/*Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente*/

SELECT 
    region.paese AS Paese,
    SUM(quantita * prezzo_unitario) AS totale,
    YEAR(data_vendita) AS anno
FROM
    region
        JOIN
    sales ON region.idregione = sales.idregione
        JOIN
    product ON sales.idprodotto = product.idprodotto
GROUP BY Paese , anno
ORDER BY anno , totale DESC;

/*Rispondere alla seguente domanda: qual è la categoria di articoli maggiormente richiesta dal mercato?*/
-- secondo la query sottostante la categoria piu richiesta sono i giochi da costruzione

select product.categoria as categoria, count(idvendita) as  totale_venduti
from product join sales on product.idprodotto = sales.idprodotto
group by categoria
order by totale_venduti desc;

/*Rispondere alla seguente domanda:
 quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti*/
 -- i prodotti invenduti sono : Puzzle da 100 pezzi,Palline colorate,Gioco di carte Uno,Libro di fiabe,Tavolo da disegno
 
 SELECT nome_prodotto
FROM product
LEFT JOIN sales ON product.idprodotto = sales.idprodotto
WHERE sales.idprodotto IS NULL;

 SELECT nome_prodotto, count(sales.quantita) as numero_venduti
FROM product
   left JOIN sales ON product.idprodotto = sales.idprodotto
  group by nome_prodotto
  having numero_venduti = 0;
  
 /*Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita più recente)*/
 
SELECT nome_prodotto,
  MAX(data_vendita) AS ultima_data_vendita
FROM product
LEFT JOIN sales ON product.idprodotto = sales.idprodotto
GROUP BY product.idprodotto, product.nome_prodotto
ORDER BY product.nome_prodotto;

-- Created by Antonino D'Ignoti
  
  
